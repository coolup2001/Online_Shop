<?php
include "header.php";
?>


<section class="section" style="min-height:40.5vh;background:whitesmoke">
<div class="container-fluid" style=>	
    <div id="cart_checkout">
    </div>
</div>
</section>	
<?php

include "footer.php";
?>